import random
num = random.randint(1,100)



while num < 50:
  print("The number is " + str(num))
  
  num += 1