"""created 1/11/21 Loops exercise: iterating over a string """

i = 0

name = "Nila"

while i < len(name):
  print("Gimme a letter!", name[i])
  i += 1

print("What does it spell?", name)