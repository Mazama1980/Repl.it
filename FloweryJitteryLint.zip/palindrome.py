"""Palindrome Checker. Created 1/25/2021. 
1) Insert a word, ie. madam, nurses run, race car.
  a)
2) Check if the word is the same in reverse.
  a) reverse word
  b) check if the word is the same
"""