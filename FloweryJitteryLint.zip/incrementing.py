import time
i = 3

while i > 0:
  print("Iteration:", i)
  time.sleep(1)
  i = i - 1