i = 0

lunch = ["soup", "smoothie", "rice bowl"]

while i < len(lunch):
  print("Choice", i, "is", lunch[i])
  i += 1

word = input("Enter a word: ")

i = 0
while i < len(word):
    print("Letter", i, "is:", word[i])
    i += 1