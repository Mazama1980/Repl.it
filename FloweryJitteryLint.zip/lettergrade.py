"""Number grade vs. letter grade."""
#You are given a number grade.
num = x


# Each letter grade has a range of two numbers
# look where the number is in the range for the letter grade

# your old version:
#look for the range of numbers that equal each letter grade

# my new version:
# look for the letter that...
# is inbetween the two numbers in the range on the same line
# look for the number that is greater than the minimum and less than the maximum on the same line



#Change the number grade to a letter grade. 