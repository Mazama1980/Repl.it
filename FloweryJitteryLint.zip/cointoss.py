import random

number = random.randint(0,1)

print("The number is ", number)

if number:
  print("You win the coin toss!")
else:
  print("Try again.")