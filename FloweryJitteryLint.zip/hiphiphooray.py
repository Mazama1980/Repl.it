cheer = "HipHip Hooray!"
yay = "Woohoo!"
i = 1

while i < 4:
  print(i, cheer)
  y = 0
  while y < 4:
    print(yay)
    y += 1
  i += 1