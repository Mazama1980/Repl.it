import random
number = 0

while number < 50:
  number = random.randint(1,100)
  print (number)
