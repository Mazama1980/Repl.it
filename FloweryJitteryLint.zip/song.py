""" Alissa helped me 1/11/21"""

song = "For he's a jolly good fellow..."

i = 3

while i > 0:
  print(song)
  i = i - 1
  
print("That nobody can deny!")
  